package com.upyogwebsite.upyog.repository;


import com.upyogwebsite.upyog.model.Facility;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FacilityRepository extends JpaRepository<Facility, Long> {

    // You can add custom query methods if needed, e.g., findByType, findByNameContaining, etc.

}

