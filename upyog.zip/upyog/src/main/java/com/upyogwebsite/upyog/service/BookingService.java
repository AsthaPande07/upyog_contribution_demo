package com.upyogwebsite.upyog.service;

import com.upyogwebsite.upyog.exception.CustomException;
import com.upyogwebsite.upyog.model.Booking;
import com.upyogwebsite.upyog.model.Facility;
import com.upyogwebsite.upyog.repository.BookingRepository;
import com.upyogwebsite.upyog.repository.FacilityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class BookingService {

    private final BookingRepository bookingRepository;
    private FacilityRepository facilityRepository;
    @Autowired
    public BookingService(BookingRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }

    // Method to create a new booking
    public Booking createBooking(Long facilityId, Booking booking) throws CustomException {
        Facility facility = facilityRepository.findById(facilityId)
                .orElseThrow(() -> new CustomException("Facility not found"));

        if (!bookingRepository.findByFacilityIdAndStartTimeBetween(
                facility, booking.getStartTime(), booking.getEndTime()).isEmpty()) {
            throw new CustomException("Time slot already booked");
        }

        booking.setFacility(facility);
        return bookingRepository.save(booking);
    }

    // Method to check if a time slot is already booked for a facility
    public boolean isBookingTimeTaken(Facility facility, LocalDateTime startDate, LocalDateTime endDate) {
        List<Booking> existingBookings = bookingRepository.findByFacilityIdAndStartTimeBetween(facility, startDate, endDate);
        return !existingBookings.isEmpty();
    }

    // Method to get all bookings for a specific facility
    public List<Booking> getBookingsByFacility(Long facility) {
        return bookingRepository.findByUserId(facility);
    }

    // Method to get a booking by its ID
    public Optional<Booking> getBookingById(Long id) {
        return bookingRepository.findById(id);
    }

    public boolean isFacilityAvailable(Facility facilityid, LocalDateTime startDate) {
        LocalDateTime endDate = startDate.plusHours(1); // assuming 1-hour slot
        List<Booking> existing = bookingRepository.findByFacilityIdAndStartTimeBetween(facilityid, startDate, endDate);
        return existing.isEmpty();
    }


    // Method to cancel a booking
    public boolean cancelBooking(Long bookingId) throws CustomException {
        Optional<Booking> bookingOpt = bookingRepository.findById(bookingId);
        if (bookingOpt.isEmpty()) {
            throw new CustomException("Booking not found.");
        }

        Booking booking = bookingOpt.get();
        booking.setStatus("Canceled");
        bookingRepository.save(booking);
        return false;
    }
}
