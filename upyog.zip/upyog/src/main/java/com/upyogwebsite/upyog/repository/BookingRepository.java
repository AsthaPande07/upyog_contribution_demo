package com.upyogwebsite.upyog.repository;


import com.upyogwebsite.upyog.model.Booking;
import com.upyogwebsite.upyog.model.Facility;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

    // Find all bookings for a given facility between two timestamps (for availability check)
    List<Booking> findByFacilityIdAndStartTimeBetween(Facility facility, LocalDateTime start, LocalDateTime end);

    // Get all active bookings (e.g., for admin or cancellation checks)
    List<Booking> findByActiveTrue();

    // Find bookings by user if needed (for user history)
    List<Booking> findByUserId(Long userId);
}
