package com.upyogwebsite.upyog.model;



import jakarta.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "facilities")
public class Facility {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    private int capacity;
    @Column(nullable = false)
    private String type; // Park, Stadium, Crematorium, Guest House, etc.

    @Column(nullable = false)
    private String location;

    @Column(length = 1000)
    private String description;

    @Column(nullable = false)
    private double hourlyRate;

    public Facility() {}

    public Facility(String name, String type, String location, String description, double hourlyRate ,int capacity) {
        this.name = name;
        this.type = type;
        this.location = location;
        this.description = description;
        this.hourlyRate = hourlyRate;
        this.capacity=capacity;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getHourlyRate() {
        return hourlyRate;
    }

    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Facility facility = (Facility) o;
        return Double.compare(facility.hourlyRate, hourlyRate) == 0 &&
                Objects.equals(id, facility.id) &&
                Objects.equals(name, facility.name) &&
                Objects.equals(type, facility.type) &&
                Objects.equals(location, facility.location) &&
                Objects.equals(description, facility.description);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, type, location, description, hourlyRate);
    }
}
