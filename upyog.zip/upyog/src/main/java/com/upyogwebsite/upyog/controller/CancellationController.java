package com.upyogwebsite.upyog.controller;


import com.upyogwebsite.upyog.model.Cancellation;
import com.upyogwebsite.upyog.service.CancellationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cancellation")
@CrossOrigin(origins = "*")
public class CancellationController {

    @Autowired
    private CancellationService cancellationService;

    @PostMapping("/cancel")
    public Cancellation cancelBooking(
            @RequestParam Long bookingId,
            @RequestParam String reason
    ) {
        return cancellationService.cancelBooking(bookingId, reason);
    }
}

