package com.upyogwebsite.upyog.model;



import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Cancellation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "booking_id", referencedColumnName = "id")
    private Booking booking;
    private String reason;
    private LocalDateTime cancellationTime;

    private double refundAmount;

    private String refundStatus; // e.g., "Pending", "Processed"

    public Cancellation() {}

    public Cancellation(Booking booking, LocalDateTime cancellationTime, double refundAmount, String refundStatus,String reason) {
        this.booking = booking;
        this.cancellationTime = cancellationTime;
        this.refundAmount = refundAmount;
        this.refundStatus = refundStatus;
        this.reason=reason;
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public Booking getBooking() {
        return booking;
    }

    public void setBooking(Booking booking) {
        this.booking = booking;
    }

    public LocalDateTime getCancellationTime() {
        return cancellationTime;
    }

    public void setCancellationTime(LocalDateTime cancellationTime) {
        this.cancellationTime = cancellationTime;
    }

    public double getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(double refundAmount) {
        this.refundAmount = refundAmount;
    }

    public String getRefundStatus() {
        return refundStatus;
    }

    public void setRefundStatus(String refundStatus) {
        this.refundStatus = refundStatus;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
