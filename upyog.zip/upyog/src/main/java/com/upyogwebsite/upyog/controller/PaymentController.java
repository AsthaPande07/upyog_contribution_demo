package com.upyogwebsite.upyog.controller;


import com.upyogwebsite.upyog.model.Payment;
import com.upyogwebsite.upyog.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payment")
@CrossOrigin(origins = "*")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @PostMapping("/process")
    public Payment processPayment(
            @RequestParam Long bookingId,
            @RequestParam double amount,
            @RequestParam String method
    ) {
        return paymentService.processPayment(bookingId, amount, method);
    }

    @GetMapping("/{bookingId}")
    public Payment getPaymentByBooking(@PathVariable Long bookingId) {
        return paymentService.getPaymentByBookingId(bookingId)
                .orElseThrow(() -> new RuntimeException("Payment not found for booking ID: " + bookingId));
    }
}

