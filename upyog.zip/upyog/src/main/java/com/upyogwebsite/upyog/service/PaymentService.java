package com.upyogwebsite.upyog.service;



import com.upyogwebsite.upyog.exception.CustomException;
import com.upyogwebsite.upyog.model.Booking;
import com.upyogwebsite.upyog.model.Payment;
import com.upyogwebsite.upyog.repository.BookingRepository;
import com.upyogwebsite.upyog.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private BookingRepository bookingRepository;

    public Payment processPayment(Long bookingId, double amount, String paymentMethod) {
        Optional<Booking> optionalBooking = bookingRepository.findById(bookingId);

        if (optionalBooking.isEmpty()) {
            throw new CustomException("Booking not found for payment.");
        }

        Booking booking = optionalBooking.get();

        if (booking.getIsPaid()) {
            throw new CustomException("Payment already made for this booking.");
        }

        Payment payment = new Payment();
        payment.setBooking(booking);
        payment.setAmount(amount);
        payment.setPaymentMethod(paymentMethod);
        payment.setPaymentTime(LocalDateTime.now());
        payment.setPaymentStatus("PAID");

        paymentRepository.save(payment);

        booking.setAmount(amount);
        bookingRepository.save(booking);

        return payment;
    }

    public Optional<Payment> getPaymentByBookingId(Long bookingId) {
        return paymentRepository.findByBookingId(bookingId);
    }
}


