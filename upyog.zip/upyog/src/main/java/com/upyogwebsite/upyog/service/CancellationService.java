package com.upyogwebsite.upyog.service;




import com.upyogwebsite.upyog.exception.CustomException;
import com.upyogwebsite.upyog.model.Booking;
import com.upyogwebsite.upyog.model.Cancellation;
import com.upyogwebsite.upyog.repository.BookingRepository;
import com.upyogwebsite.upyog.repository.CancellationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class CancellationService {

    @Autowired
    private CancellationRepository cancellationRepository;

    @Autowired
    private BookingRepository bookingRepository;

    public Cancellation cancelBooking(Long bookingId, String reason) {
        Optional<Booking> optionalBooking = bookingRepository.findById(bookingId);

        if (optionalBooking.isEmpty()) {
            throw new CustomException("Booking not found for cancellation.");
        }

        Booking booking = optionalBooking.get();

        if (booking.getStartTime().isBefore(LocalDateTime.now())) {
            throw new CustomException("Cannot cancel past bookings.");
        }

        Cancellation cancellation = new Cancellation();
        cancellation.setBooking(booking);
        cancellation.setReason(reason);
        cancellation.setCancellationTime(LocalDateTime.now());
        cancellation.setRefundAmount(calculateRefund(booking.getAmount()));

        cancellationRepository.save(cancellation);

        booking.setStatus(String.valueOf(true));
        bookingRepository.save(booking);

        return cancellation;
    }

    private double calculateRefund(double amount) {
        // Simple 80% refund logic
        return amount * 0.80;
    }
}

