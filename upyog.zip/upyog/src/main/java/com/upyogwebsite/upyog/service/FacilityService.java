package com.upyogwebsite.upyog.service;

import com.upyogwebsite.upyog.model.Facility;
import com.upyogwebsite.upyog.repository.FacilityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FacilityService {

    @Autowired
    private FacilityRepository facilityRepository;

    // Get all facilities
    public List<Facility> getAllFacilities() {
        return facilityRepository.findAll();
    }

    // Get facility by ID
    public Optional<Facility> getFacilityById(Long id) {
        return facilityRepository.findById(id);
    }

    // Add new facility
    public Facility addFacility(Facility facility) {
        return facilityRepository.save(facility);
    }

    // Update existing facility
    public Facility updateFacility(Long id, Facility updatedFacility) {
        return facilityRepository.findById(id).map(facility -> {
            facility.setName(updatedFacility.getName());
            facility.setType(updatedFacility.getType());
            facility.setLocation(updatedFacility.getLocation());
            facility.setCapacity(updatedFacility.getCapacity());
            return facilityRepository.save(facility);
        }).orElseThrow(() -> new RuntimeException("Facility not found for id: " + id));
    }

    // Delete facility
    public void deleteFacility(Long id) {
        facilityRepository.deleteById(id);
    }
}

