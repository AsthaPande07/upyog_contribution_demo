package com.upyogwebsite.upyog.config;

public class Security {
}
