package com.upyogwebsite.upyog.service;

public class AvailabilityService {
}
