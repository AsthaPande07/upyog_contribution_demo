package com.upyogwebsite.upyog.controller;

import com.upyogwebsite.upyog.model.Facility;
import com.upyogwebsite.upyog.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    @Autowired
    private BookingService bookingService;


    @GetMapping("/check-availability")
    public ResponseEntity<Boolean> checkAvailability(
            @RequestParam Facility facilityId,
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm") LocalDateTime startDate) {

        boolean isAvailable = bookingService.isFacilityAvailable(facilityId, startDate);
        return ResponseEntity.ok(isAvailable);
    }



    @PostMapping("/cancel")
    public ResponseEntity<String> cancelBooking(@RequestParam Long bookingId) {
        boolean isCancelled = bookingService.cancelBooking(bookingId);
        if (isCancelled) {
            return ResponseEntity.ok("Booking cancelled successfully. Refund processed.");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Cancellation failed.");
        }
    }
}


