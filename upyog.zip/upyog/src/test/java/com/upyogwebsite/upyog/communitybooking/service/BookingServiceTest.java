package com.upyogwebsite.upyog.communitybooking.service;

public class BookingServiceTest {
}
