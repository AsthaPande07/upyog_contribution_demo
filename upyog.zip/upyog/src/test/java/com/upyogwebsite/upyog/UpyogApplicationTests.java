package com.upyogwebsite.upyog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UpyogApplicationTests {

	@Test
	void contextLoads() {
	}

}
